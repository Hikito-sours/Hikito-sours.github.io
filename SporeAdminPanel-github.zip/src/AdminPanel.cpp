﻿#include "stdafx.h"
#include "AdminPanel.h"
#include <Spore\Simulator.h>
#include <cwchar>
#include <string>

using namespace Simulator;

namespace
{
	// ---------------------------------------------------------------- данные

	struct CmdButton
	{
		const wchar_t* label;
		const char* command;  // консольная команда Spore (Ctrl+Shift+C)
	};

	// Все эти команды встроенные в Spore, панель просто запускает их кнопками.
	const CmdButton kResources[] = {
		{ L"+ДНК (addDNA)",              "addDNA" },
		{ L"+Деньги (moreMoney)",        "moreMoney" },
		{ L"Восстановить здоровье",      "refillMotives" },
		{ L"Супероружие",                "unlockSuperWeapons" },
		{ L"Космоинструменты",           "spaceCreate" },
	};

	const CmdButton kGameplay[] = {
		{ L"Открыть все стадии (меню)",  "levels -unlock" },
		{ L"Свободная камера",           "freeCam" },
		{ L"Снять лимиты редактора",     "freedom on" },
		{ L"Убрать подсказки",           "killallhints" },
	};

	const CmdButton kSpace[] = {
		{ L"Захват планеты (zealot)",    "setConsequenceTrait space_zealot" },
		{ L"Роль: торговец",             "setConsequenceTrait space_trader" },
		{ L"Роль: воин",                 "setConsequenceTrait space_warrior" },
		{ L"Роль: ученый",               "setConsequenceTrait space_scientist" },
	};

	enum ControlIDs
	{
		ID_RUN_CMD = 1000,
		ID_SPAWN_BY_ID,
		ID_SPAWN_DEFAULT,
		ID_SPAWN_ROCK,
		ID_RENAME_PLANET,
		ID_PLANET_INFO,
		ID_CMD_BASE = 2000,   // дальше идут кнопки из таблиц выше
	};

	// Тестовые ключи из документации ModAPI. Если такого ресурса нет — спавн сообщит об ошибке.
	const uint32_t kDefaultCreatureID = 0x066B8241;

	HWND gWnd = nullptr;
	HWND gStatus = nullptr;
	HWND gEditCmd = nullptr;
	HWND gEditCreatureID = nullptr;
	HWND gEditName = nullptr;

	const wchar_t* kClassName = L"SporeAdminPanelWindow";

	// ---------------------------------------------------------------- утилиты

	void SetStatus(const std::wstring& text)
	{
		if (gStatus) SetWindowTextW(gStatus, text.c_str());
	}

	std::string ToNarrow(const std::wstring& s)
	{
		if (s.empty()) return std::string();
		int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0, nullptr, nullptr);
		std::string out(n, '\0');
		WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n, nullptr, nullptr);
		return out;
	}

	std::wstring GetText(HWND edit)
	{
		wchar_t buf[512] = {};
		GetWindowTextW(edit, buf, 512);
		return buf;
	}

	std::wstring ToWide(const char* s)
	{
		return std::wstring(s, s + strlen(s));
	}

	// ---------------------------------------------------------------- действия

	void RunConsole(const std::string& command)
	{
		if (command.empty()) return;

		bool ok = App::ICheatManager::Get()->ProcessLine(command.c_str());
		App::ConsolePrintF("[AdminPanel] %s", command.c_str());

		SetStatus(L"> " + ToWide(command.c_str()) + (ok ? L"  -  выполнено"
			: L"  -  не выполнено (нет такой команды или не та стадия игры)"));
	}

	void SpawnCreature(uint32_t instanceID)
	{
		auto avatar = GameNounManager.GetAvatar();
		if (!avatar)
		{
			SetStatus(L"Нет аватара: зайди в игру на стадии существа/племени/цивилизации/космоса.");
			return;
		}

		auto species = SpeciesManager.GetSpeciesProfile({ instanceID, TypeIDs::crt, GroupIDs::CreatureModels });
		if (!species)
		{
			SetStatus(L"Не найдено существо с таким ID.");
			return;
		}

		Math::Vector3 pos = avatar->GetPosition();
		pos.x += 5.0f;
		pos = PlanetModel.ToSurface(pos);

		cCreatureAnimalPtr creature = cCreatureAnimal::Create(pos, species);
		SetStatus(creature ? L"Существо создано рядом с аватаром." : L"Не удалось создать существо.");
	}

	void SpawnRock()
	{
		auto avatar = GameNounManager.GetAvatar();
		if (!avatar)
		{
			SetStatus(L"Нет аватара: объект появляется рядом с ним.");
			return;
		}

		Math::Vector3 pos = avatar->GetPosition();
		pos.x -= 5.0f;
		pos = PlanetModel.ToSurface(pos);

		cGameDataPtr rock = GameNounManager.CreateInstance(kRock);
		auto obj = object_cast<cSpatialObject>(rock);
		if (!obj)
		{
			SetStatus(L"Не удалось создать объект.");
			return;
		}
		obj->SetModelKey({ id("EP1_sg_rare_fossils_04"), TypeIDs::prop, GroupIDs::CivicObjects });
		obj->SetPosition(pos);
		SetStatus(L"Объект создан рядом с аватаром.");
	}

	void ShowPlanetInfo()
	{
		auto star = GetActiveStarRecord();
		auto planet = GetActivePlanetRecord();
		if (!star || !planet)
		{
			SetStatus(L"Активной планеты нет (нужна космическая стадия).");
			return;
		}

		float tscore = TerraformingManager.GetTScore(planet);
		wchar_t buf[256];
		swprintf_s(buf, L"Звезда: %ls  |  T-score планеты: %.2f",
			reinterpret_cast<const wchar_t*>(star->mName.c_str()), tscore);
		SetStatus(buf);
	}

	void RenameSelectedPlanet()
	{
		std::wstring name = GetText(gEditName);
		if (name.empty())
		{
			SetStatus(L"Впиши новое имя планеты.");
			return;
		}
		// Сначала выдели планету в игре, потом жми кнопку.
		RunConsole("rename planet " + ToNarrow(name));
	}

	// Таблица кнопок -> команда по индексу
	const char* LookupCommand(int id)
	{
		int index = id - ID_CMD_BASE;
		int n1 = (int)(sizeof(kResources) / sizeof(kResources[0]));
		int n2 = (int)(sizeof(kGameplay) / sizeof(kGameplay[0]));
		int n3 = (int)(sizeof(kSpace) / sizeof(kSpace[0]));
		if (index < 0) return nullptr;
		if (index < n1) return kResources[index].command;
		index -= n1;
		if (index < n2) return kGameplay[index].command;
		index -= n2;
		if (index < n3) return kSpace[index].command;
		return nullptr;
	}

	// ---------------------------------------------------------------- окно

	HWND MakeLabel(HWND parent, const wchar_t* text, int x, int y, int w, int h)
	{
		return CreateWindowExW(0, L"STATIC", text, WS_CHILD | WS_VISIBLE, x, y, w, h, parent, nullptr, nullptr, nullptr);
	}

	HWND MakeButton(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h)
	{
		return CreateWindowExW(0, L"BUTTON", text, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			x, y, w, h, parent, (HMENU)(INT_PTR)id, nullptr, nullptr);
	}

	HWND MakeEdit(HWND parent, const wchar_t* text, int x, int y, int w, int h)
	{
		return CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", text, WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
			x, y, w, h, parent, nullptr, nullptr, nullptr);
	}

	// Рисуем секцию кнопок в два столбца, возвращаем новую координату y.
	template <size_t N>
	int AddSection(HWND parent, const wchar_t* title, const CmdButton(&buttons)[N], int idStart, int y)
	{
		const int colW = 200, rowH = 28, gap = 6, x0 = 12;
		MakeLabel(parent, title, x0, y, 400, 18);
		y += 22;
		for (size_t i = 0; i < N; ++i)
		{
			int x = x0 + (int)(i % 2) * (colW + gap);
			int yy = y + (int)(i / 2) * (rowH + gap);
			MakeButton(parent, buttons[i].label, idStart + (int)i, x, yy, colW, rowH);
		}
		return y + (int)((N + 1) / 2) * (rowH + gap) + 8;
	}

	void BuildControls(HWND hwnd)
	{
		const int colW = 200, rowH = 28, gap = 6, x0 = 12;
		int y = 10;

		int id = ID_CMD_BASE;
		y = AddSection(hwnd, L"Ресурсы", kResources, id, y);
		id += (int)(sizeof(kResources) / sizeof(kResources[0]));
		y = AddSection(hwnd, L"Игровой процесс", kGameplay, id, y);
		id += (int)(sizeof(kGameplay) / sizeof(kGameplay[0]));

		// --- спавн
		MakeLabel(hwnd, L"Спавн (рядом с аватаром)", x0, y, 400, 18);
		y += 22;
		MakeButton(hwnd, L"Существо (по умолчанию)", ID_SPAWN_DEFAULT, x0, y, colW, rowH);
		MakeButton(hwnd, L"Объект (ископаемое)", ID_SPAWN_ROCK, x0 + colW + gap, y, colW, rowH);
		y += rowH + gap;
		MakeLabel(hwnd, L"ID существа (hex):", x0, y + 4, 130, 18);
		gEditCreatureID = MakeEdit(hwnd, L"066B8241", x0 + 132, y, 120, 24);
		MakeButton(hwnd, L"Создать по ID", ID_SPAWN_BY_ID, x0 + colW + gap, y - 2, colW, rowH);
		y += rowH + 12;

		// --- космос и планеты
		y = AddSection(hwnd, L"Планеты и космос", kSpace, id, y);
		MakeLabel(hwnd, L"Имя планеты:", x0, y + 4, 90, 18);
		gEditName = MakeEdit(hwnd, L"", x0 + 92, y, 160, 24);
		MakeButton(hwnd, L"Переименовать выбранную", ID_RENAME_PLANET, x0 + colW + gap, y - 2, colW, rowH);
		y += rowH + gap;
		MakeButton(hwnd, L"Инфо об активной планете", ID_PLANET_INFO, x0, y, colW, rowH);
		y += rowH + 12;

		// --- любая консольная команда
		MakeLabel(hwnd, L"Любая консольная команда Spore", x0, y, 400, 18);
		y += 22;
		gEditCmd = MakeEdit(hwnd, L"", x0, y, 300, 24);
		MakeButton(hwnd, L"Выполнить", ID_RUN_CMD, x0 + 306, y - 2, 94, rowH);
		y += rowH + 12;

		// --- статус
		gStatus = MakeLabel(hwnd, L"Insert - показать/скрыть панель.", x0, y, 400, 36);

		// шрифт как у системы
		HFONT font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
		EnumChildWindows(hwnd, [](HWND child, LPARAM lp) -> BOOL {
			SendMessageW(child, WM_SETFONT, (WPARAM)lp, TRUE);
			return TRUE;
		}, (LPARAM)font);
	}

	LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
	{
		switch (msg)
		{
		case WM_COMMAND:
		{
			int id = LOWORD(wp);
			if (HIWORD(wp) != BN_CLICKED) break;

			if (id >= ID_CMD_BASE)
			{
				if (const char* cmd = LookupCommand(id)) RunConsole(cmd);
				return 0;
			}

			switch (id)
			{
			case ID_RUN_CMD:        RunConsole(ToNarrow(GetText(gEditCmd))); break;
			case ID_SPAWN_DEFAULT:  SpawnCreature(kDefaultCreatureID); break;
			case ID_SPAWN_ROCK:     SpawnRock(); break;
			case ID_PLANET_INFO:    ShowPlanetInfo(); break;
			case ID_RENAME_PLANET:  RenameSelectedPlanet(); break;
			case ID_SPAWN_BY_ID:
			{
				std::wstring text = GetText(gEditCreatureID);
				wchar_t* end = nullptr;
				unsigned long value = wcstoul(text.c_str(), &end, 16);
				if (text.empty() || (end && *end != L'\0'))
					SetStatus(L"ID должен быть числом в hex, например 066B8241.");
				else
					SpawnCreature((uint32_t)value);
				break;
			}
			}
			return 0;
		}
		case WM_CLOSE:
			ShowWindow(hwnd, SW_HIDE);  // не уничтожаем, просто прячем
			return 0;
		case WM_DESTROY:
			gWnd = nullptr;
			return 0;
		}
		return DefWindowProcW(hwnd, msg, wp, lp);
	}

	bool CreatePanel()
	{
		static bool registered = false;
		if (!registered)
		{
			WNDCLASSW wc = {};
			wc.lpfnWndProc = WndProc;
			wc.hInstance = GetModuleHandleW(nullptr);
			wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
			wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
			wc.lpszClassName = kClassName;
			if (!RegisterClassW(&wc)) return false;
			registered = true;
		}

		HWND owner = GetActiveWindow();
		if (!owner) owner = GetForegroundWindow();

		RECT rc = { 0, 0, 424, 640 };
		DWORD style = WS_POPUP | WS_CAPTION | WS_SYSMENU;
		AdjustWindowRectEx(&rc, style, FALSE, WS_EX_TOPMOST | WS_EX_TOOLWINDOW);

		gWnd = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, kClassName, L"Админ-панель Spore",
			style, 40, 40, rc.right - rc.left, rc.bottom - rc.top, owner, nullptr, GetModuleHandleW(nullptr), nullptr);
		if (!gWnd) return false;

		BuildControls(gWnd);
		return true;
	}
}

namespace AdminPanel
{
	void Toggle()
	{
		if (!gWnd && !CreatePanel())
		{
			App::ConsolePrintF("[AdminPanel] не удалось создать окно");
			return;
		}

		if (IsWindowVisible(gWnd))
		{
			ShowWindow(gWnd, SW_HIDE);
		}
		else
		{
			ShowWindow(gWnd, SW_SHOWNOACTIVATE);
			SetForegroundWindow(gWnd);
		}
	}

	void Shutdown()
	{
		if (gWnd) DestroyWindow(gWnd);
		gWnd = nullptr;
	}
}
