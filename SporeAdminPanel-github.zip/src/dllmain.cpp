﻿// dllmain.cpp: админ-панель для Spore (Spore ModAPI).
//
// Если шаблон проекта создал dllmain.cpp с другим DllMain - оставь свой DllMain,
// а сюда перенеси только Initialize(), Dispose() и классы выше них.

#include "stdafx.h"
#include "AdminPanel.h"

// Горячая клавиша открытия панели (Insert). Список кодов: VK_F1..VK_F12, VK_HOME и т.д.
static const int kHotkey = VK_INSERT;

// ------------------------------------------------------------------ горячая клавиша

class HotkeyProc
	: public UTFWin::IWinProc
	, public DefaultRefCounted
{
public:
	static const uint32_t TYPE = id("SporeAdminPanel::HotkeyProc");

	int AddRef() override { return DefaultRefCounted::AddRef(); }
	int Release() override { return DefaultRefCounted::Release(); }

	void* Cast(uint32_t type) const override
	{
		CLASS_CAST(Object);
		CLASS_CAST(UTFWin::IWinProc);
		CLASS_CAST(HotkeyProc);
		return nullptr;
	}

	int GetEventFlags() const override
	{
		return UTFWin::kEventFlagBasicInput;
	}

	bool HandleUIMessage(UTFWin::IWindow*, const UTFWin::Message& message) override
	{
		if (message.IsType(UTFWin::kMsgKeyDown) && message.Key.vkey == kHotkey)
		{
			AdminPanel::Toggle();
			return true;
		}
		return false;
	}
};

// ------------------------------------------------------------------ консольная команда

// Запасной вариант: команда adminPanel в консоли (Ctrl+Shift+C) тоже открывает панель.
class AdminPanelCheat
	: public ArgScript::ICommand
{
public:
	void ParseLine(const ArgScript::Line& line) override
	{
		AdminPanel::Toggle();
	}

	const char* GetDescription(ArgScript::DescriptionMode mode) const override
	{
		return mode == ArgScript::DescriptionMode::Basic
			? "Opens the admin panel window."
			: "adminPanel: opens or hides the admin panel window.";
	}
};

// ------------------------------------------------------------------ точки входа мода

void Initialize()
{
	CheatManager.AddCheat("adminPanel", new AdminPanelCheat());

	if (auto mainWindow = WindowManager.GetMainWindow())
	{
		mainWindow->AddWinProc(new HotkeyProc());
	}
}

void Dispose()
{
	AdminPanel::Shutdown();
}

void AttachDetours()
{
	// детуры не нужны
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		ModAPI::AddPostInitFunction(Initialize);
		ModAPI::AddDisposeFunction(Dispose);

		PrepareDetours(hModule);
		AttachDetours();
		CommitDetours();
		break;

	case DLL_PROCESS_DETACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}
	return TRUE;
}
